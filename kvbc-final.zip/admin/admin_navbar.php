<nav class="navbar navbar-expand-lg navbar-dark bg-danger">
  <a class="navbar-brand" href="admin_home.php">Admin Dashboard</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">

      <li class="nav-item ">
        <a class="nav-link" href="admin_home.php">Home</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_users.php">Users</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="add_vaccination.php">Vaccinations</a>
      </li>     
      <li class="nav-item ">
        <a class="nav-link" href="admin_view_bookings.php">Appointments</a>
      </li>     
      <li class="nav-item ">
        <a class="nav-link" href="generate_reports.php">Reports</a>
      </li>     
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
    </ul>
  </div>
</nav>
